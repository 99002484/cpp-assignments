#include "customer.h"

Customer::Customer():id(0.0),name(""),number(""),balance(0.0){}
Customer::Customer(double Pid,std::string Pname,std::string Pnumber,double Pbalance):id(Pid),name(Pname),number(Pnumber),balance(Pbalance){}

std::string Customer::getCustomerName(){
return name;
}

double Customer::getCustomerId(){
return id;
}

double Customer::getBalance()
{
    return balance;
}

void Customer::setbalance(double amount)
{
    balance=balance+amount;
}

std::string Customer::getCustomerNumber(){
return number;
}
